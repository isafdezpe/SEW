function escribeTitulo3() {
    document.write("<h3>" + cabecera.centro + "</h3>");
}

escribeTitulo3();