function escribeParrafos() {
    document.write("<p>" + cabecera.nombre + "</p>");
    document.write("<p>" + cabecera.email + "</p>");
}

escribeParrafos();