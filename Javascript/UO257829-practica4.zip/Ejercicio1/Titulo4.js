function escribeTitulo4() {
    document.write("<h4>" + cabecera.universidad + "</h4>");
}

escribeTitulo4();