function escribeTitulo2() {
    document.write("<h2>" + cabecera.titulacion + "</h2>");
}

escribeTitulo2();