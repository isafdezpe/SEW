//Cabecera.js
var cabecera = new Object();
cabecera.asignatura = "Software y Estándares para la Web";
cabecera.titulacion = "Grado en Ingeniería Informática del Software";
cabecera.centro = "Escuela de Ingeniería Informática";
cabecera.universidad = "Universidad de Oviedo";
cabecera.nombre = "Mª Isabel Fernández Pérez";
cabecera.email = "UO257829@uniovi.es";