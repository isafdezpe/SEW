function escribeTitulo1() {
    document.write("<h1>" + cabecera.asignatura + "</h1>");
}

escribeTitulo1();