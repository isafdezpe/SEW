function escribeNombre() {
    document.write(navegador.nombre);
}

escribeNombre();