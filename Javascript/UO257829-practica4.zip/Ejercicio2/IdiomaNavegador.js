function escribeIdioma() {
    document.write(navegador.lenguaje);
}

escribeIdioma();